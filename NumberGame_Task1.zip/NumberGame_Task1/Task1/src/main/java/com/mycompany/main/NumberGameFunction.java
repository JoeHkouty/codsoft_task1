package com.mycompany.main;

import java.util.Random;

public class NumberGameFunction {

    public static String playGame(int number, int randomNumber, int attempts) {
        int maxAttempts = 10;
        int score = 0;
        String result = "";

        do {
            boolean numberGuessed = false;
            System.out.println(randomNumber);
            while (attempts < maxAttempts && !numberGuessed) {
                attempts++;

                if (number == randomNumber) {
                    numberGuessed = true;
                    score += maxAttempts - attempts + 1;
                    result = "Congratulations! You guessed the correct number in " + (attempts-1) + " attempts.";
                    System.out.println("1");
                    return result;
                } else if (randomNumber - number >= 10) {
                    result = "Your entered Number is Too low! Try again.";
                    System.out.println("2");
                    return result;
                } else if (number - randomNumber >= 10) {
                    result = "Your entered Number is Too high! Try again.";
                    System.out.println("3");
                    return result;
                } else if (randomNumber - number < 10 && randomNumber - number > 0) {
                    result = "You're close! The correct number is higher than your guessed number, Try again.";
                    System.out.println("4");
                    return result;
                } else if (number - randomNumber < 10 && number - randomNumber > 0) {
                    result = "You're close! The correct number is lower than your guessed number, Try again.";
                    System.out.println("5");
                    return result;
                }
            }

            if (!numberGuessed) {
                result = "Sorry, you've reached the maximum number of attempts. The correct number was: " + randomNumber;
            }

        } while (false); // For now, we're not supporting multiple rounds

        return result;
    }


}
